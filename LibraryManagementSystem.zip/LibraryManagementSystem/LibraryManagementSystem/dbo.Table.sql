﻿CREATE TABLE [dbo].[Table]
(
	[StudentId] INT NOT NULL PRIMARY KEY, 
    [StudentName] VARCHAR(100) NOT NULL, 
    [Contact] CHAR(10) NOT NULL, 
    [BookId] VARCHAR(50) NOT NULL, 
    [IssueDate] SMALLDATETIME NOT NULL, 
    [ReturnDate] SMALLDATETIME NULL
)
