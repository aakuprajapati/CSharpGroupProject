﻿CREATE TABLE [dbo].[Table] (
    [StudentId]   INT           NOT NULL,
    [StudentName] VARCHAR (100) NOT NULL,
    [Contact]     CHAR (10)     NOT NULL,
    [BookId]      VARCHAR (50)  NOT NULL,
    [IssueDate]   SMALLDATETIME NULL,
    [ReturnDate]  SMALLDATETIME NULL,
    PRIMARY KEY CLUSTERED ([StudentId] ASC)
);

