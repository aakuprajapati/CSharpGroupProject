﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;





namespace LibraryManagementSystem
{
    public partial class IssueBook : Form


    {
        String str;
       

      
        public IssueBook()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox6.Clear();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\angel\\Desktop\\LibraryManagementSystem\\LibraryManagementSystem\\library.mdf;Integrated Security=True");

                cn.Open();
                str = "insert into dbo.[Table](StudentId, StudentName, Contact, BookId , IssueDate) values (@textBox1 , @textBox2, @textBox3, @textBox6 , @textBox4)";
                SqlCommand cmd = new SqlCommand(str, cn);
                cmd.Parameters.AddWithValue("@textBox1", textBox1.Text);
                cmd.Parameters.AddWithValue("@textBox2", textBox2.Text);
                cmd.Parameters.AddWithValue("@textBox3", textBox3.Text);
                cmd.Parameters.AddWithValue("@textBox6", textBox6.Text);
                cmd.Parameters.AddWithValue("@textBox4", textBox4.Text);

                cmd.ExecuteNonQuery();
                cn.Close();
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox6.Clear();
            }
            catch (Exception exc)
            {
                Console.WriteLine("Error: " + exc.Message);
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\angel\\Desktop\\LibraryManagementSystem\\LibraryManagementSystem\\library.mdf;Integrated Security=True");

                cn.Open();

            }
            catch (Exception exc)
            {
                Console.WriteLine("Error: " + exc.Message);
            }

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        

        private void StudentId_Click(object sender, EventArgs e)
        {

        }

        private void Register_Click(object sender, EventArgs e)
        {

        }

        private void Home_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Main m1 = new Main();
            m1.Show();
        }
    }
}
