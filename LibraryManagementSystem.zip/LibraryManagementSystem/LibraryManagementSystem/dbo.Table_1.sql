﻿CREATE TABLE [dbo].[Table_1]
(
	[BookId] VARCHAR(50) NOT NULL PRIMARY KEY, 
    [BookName] VARCHAR(50) NOT NULL, 
    [BookAuthor] VARCHAR(50) NOT NULL, 
    [BookVolume] VARCHAR(50) NOT NULL, 
    [BookType] VARCHAR(50) NOT NULL, 
   
)
