﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManagementSystem
{
    public partial class AddBook : Form
    {

        String str;


        public AddBook()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\angel\\Desktop\\LibraryManagementSystem\\LibraryManagementSystem\\library.mdf;Integrated Security=True");

                cn.Open();
            }

            catch(Exception exc)
            {
                Console.WriteLine("Error: " + exc.Message);
            }
        }

        private void Register_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try 
            { 
                SqlConnection cn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\angel\\Desktop\\LibraryManagementSystem\\LibraryManagementSystem\\library.mdf;Integrated Security=True");

                cn.Open();
                str = "insert into dbo.[Table_1](BookId, BookName, BookAuthor, BookVolume , BookType) values (@textBox1 , @textBox2, @textBox3, @textBox4 , @textBox5)";
                SqlCommand cmd = new SqlCommand(str, cn);
                cmd.Parameters.AddWithValue("@textBox1", textBox1.Text);
                cmd.Parameters.AddWithValue("@textBox2", textBox2.Text);
                cmd.Parameters.AddWithValue("@textBox3", textBox3.Text);
                cmd.Parameters.AddWithValue("@textBox4", textBox4.Text);
                cmd.Parameters.AddWithValue("@textBox5", textBox5.Text);

                cmd.ExecuteNonQuery();
                cn.Close();
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();

            }
            catch (Exception exc)
            {
                Console.WriteLine("Error: " + exc.Message);
            }

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void IssueDate_Click(object sender, EventArgs e)
        {

        }

        private void Contact_Click(object sender, EventArgs e)
        {

        }

        private void StudentName_Click(object sender, EventArgs e)
        {

        }

        private void StudentId_Click(object sender, EventArgs e)
        {

        }

        private void Home_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Main m1 = new Main();
            m1.Show();
        }
    }
}
