﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace LibraryManagementSystem
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void table_1BindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.table_1BindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dataSet);

        }

        private void Main_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet.Table_1' table. You can move, or remove it, as needed.
            this.table_1TableAdapter.Fill(this.dataSet.Table_1);
            refreshdata();
        }

        private void refreshdata()
        {
            SqlConnection cn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\angel\\Desktop\\LibraryManagementSystem\\LibraryManagementSystem\\library.mdf;Integrated Security=True");

            cn.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM dbo.[Table]", cn);
            
            
            cn.Close();
        }

        private void addNewBook_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddBook f2 = new AddBook();
            f2.Show();

        }

        private void returnBook_Click(object sender, EventArgs e)
        {
            this.Hide();
            ReturnBook r1 = new ReturnBook();
            r1.Show();
        }

        private void IssueBook_Click(object sender, EventArgs e)
        {
            this.Hide();
            IssueBook f2 = new IssueBook();
            f2.Show();
        }


        private void button1_Click_1(object sender, EventArgs e)
        {
            // creating Excel Application  
            Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
            // creating new WorkBook within Excel application  
            Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
            // creating new Excelsheet in workbook  
            Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
            // see the excel sheet behind the program  
            app.Visible = true;
            // get the reference of first sheet. By default its name is Sheet1.  
            // store its reference to worksheet  
            worksheet = workbook.Sheets["Sheet1"];
            worksheet = workbook.ActiveSheet;
            // changing the name of active sheet  
            worksheet.Name = "Exported from gridview";    //current sheet name
            // storing header part in Excel  
            for (int i = 1; i < table_1DataGridView.Columns.Count + 1; i++)
            {
                worksheet.Cells[1, i] = table_1DataGridView.Columns[i - 1].HeaderText;
            }
            // storing Each row and column value to excel sheet  
            for (int i = 0; i < table_1DataGridView.Rows.Count - 1; i++)  //Row 
            {
                for (int j = 0; j < table_1DataGridView.Columns.Count; j++) //Column
                {
                    worksheet.Cells[i + 2, j + 1] = table_1DataGridView.Rows[i].Cells[j].Value.ToString();
                }
            }
            // save the application == file name 
            workbook.SaveAs("c:\\comp1098\\output.xls", Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
